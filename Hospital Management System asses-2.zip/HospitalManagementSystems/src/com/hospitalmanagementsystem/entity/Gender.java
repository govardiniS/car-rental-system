package com.hospitalmanagementsystem.entity;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
