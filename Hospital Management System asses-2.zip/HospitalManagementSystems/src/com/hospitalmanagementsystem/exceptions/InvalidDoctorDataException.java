package com.hospitalmanagementsystem.exceptions;

public class InvalidDoctorDataException extends Exception {
    public InvalidDoctorDataException(String message) {
        super(message);
    }
}