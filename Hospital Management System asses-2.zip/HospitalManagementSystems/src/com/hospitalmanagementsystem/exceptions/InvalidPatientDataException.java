package com.hospitalmanagementsystem.exceptions;


public class InvalidPatientDataException extends Exception {
    public InvalidPatientDataException(String message) {
        super(message);
    }
}